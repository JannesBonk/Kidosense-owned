﻿using System;

namespace ManualMapInjection.Injection.Win32
{
	// Token: 0x0200001A RID: 26
	public struct UNICODE_STRING
	{
		// Token: 0x04000108 RID: 264
		public ushort Length;

		// Token: 0x04000109 RID: 265
		public ushort MaximumLength;

		// Token: 0x0400010A RID: 266
		public IntPtr Buffer;
	}
}
