﻿using System;

namespace ManualMapInjection.Injection.Win32
{
	// Token: 0x02000021 RID: 33
	public struct FILETIME
	{
		// Token: 0x0400013D RID: 317
		public uint DateTimeLow;

		// Token: 0x0400013E RID: 318
		public uint DateTimeHigh;
	}
}
