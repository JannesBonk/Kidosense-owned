﻿using System;

namespace ManualMapInjection.Injection.Win32
{
	// Token: 0x02000012 RID: 18
	public struct IMAGE_DATA_DIRECTORY
	{
		// Token: 0x0400008F RID: 143
		public uint VirtualAddress;

		// Token: 0x04000090 RID: 144
		public uint Size;
	}
}
