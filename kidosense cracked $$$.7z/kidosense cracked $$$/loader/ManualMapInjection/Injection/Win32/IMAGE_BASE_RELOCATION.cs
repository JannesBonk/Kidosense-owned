﻿using System;

namespace ManualMapInjection.Injection.Win32
{
	// Token: 0x0200001E RID: 30
	public struct IMAGE_BASE_RELOCATION
	{
		// Token: 0x0400011C RID: 284
		public uint VirtualAddress;

		// Token: 0x0400011D RID: 285
		public uint SizeOfBlock;
	}
}
