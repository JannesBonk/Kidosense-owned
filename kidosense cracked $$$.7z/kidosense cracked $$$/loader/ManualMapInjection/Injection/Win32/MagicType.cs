﻿using System;

namespace ManualMapInjection.Injection.Win32
{
	// Token: 0x0200000C RID: 12
	public enum MagicType : ushort
	{
		// Token: 0x0400002E RID: 46
		IMAGE_NT_OPTIONAL_HDR32_MAGIC = 267,
		// Token: 0x0400002F RID: 47
		IMAGE_NT_OPTIONAL_HDR64_MAGIC = 523
	}
}
