﻿using System;

namespace ManualMapInjection.Injection.Win32
{
	// Token: 0x0200001D RID: 29
	public struct IMAGE_IMPORT_BY_NAME
	{
		// Token: 0x0400011A RID: 282
		public short Hint;

		// Token: 0x0400011B RID: 283
		public char Name;
	}
}
