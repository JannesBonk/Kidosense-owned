﻿using System;

namespace ManualMapInjection.Injection.Win32
{
	// Token: 0x0200000B RID: 11
	public enum MachineType : ushort
	{
		// Token: 0x04000029 RID: 41
		Native,
		// Token: 0x0400002A RID: 42
		I386 = 332,
		// Token: 0x0400002B RID: 43
		Itanium = 512,
		// Token: 0x0400002C RID: 44
		x64 = 34404
	}
}
